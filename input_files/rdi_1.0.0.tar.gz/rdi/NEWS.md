Version 1.0.0:  May 1, 2018
-------------------------------------------------------------------------------

Internal changes and extra documentation for submission to CRAN.

Some variable names changed for consistency:

- n_iter changed to nIter
- label.ladder changed to labelLadder
- line.col changed to lineCol
- fill.col changed to fillCol


Version 0.9.0:  October 12, 2016
-------------------------------------------------------------------------------

Initial public release.
