#' @import gplots
#' @import beanplot
#' @import stringr
#' @import pdist
#' @importFrom stats runif rnorm qnorm dnorm rbinom rhyper dist as.dist cor predict approx smooth.spline var
#' @importFrom graphics plot par strwidth strheight polygon lines text axis
NULL